# new_tab_suspender

A very lightweight tab suspender that reduces an overall memory usage of chrome, uses chrome native discard api
